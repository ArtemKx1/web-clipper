// node_modules/uuid/dist/esm-browser/rng.js
var getRandomValues;
var rnds8 = new Uint8Array(16);
function rng() {
  if (!getRandomValues) {
    getRandomValues = typeof crypto !== "undefined" && crypto.getRandomValues && crypto.getRandomValues.bind(crypto);
    if (!getRandomValues) {
      throw new Error("crypto.getRandomValues() not supported. See https://github.com/uuidjs/uuid#getrandomvalues-not-supported");
    }
  }
  return getRandomValues(rnds8);
}

// node_modules/uuid/dist/esm-browser/stringify.js
var byteToHex = [];
for (let i = 0; i < 256; ++i) {
  byteToHex.push((i + 256).toString(16).slice(1));
}
function unsafeStringify(arr, offset = 0) {
  return byteToHex[arr[offset + 0]] + byteToHex[arr[offset + 1]] + byteToHex[arr[offset + 2]] + byteToHex[arr[offset + 3]] + "-" + byteToHex[arr[offset + 4]] + byteToHex[arr[offset + 5]] + "-" + byteToHex[arr[offset + 6]] + byteToHex[arr[offset + 7]] + "-" + byteToHex[arr[offset + 8]] + byteToHex[arr[offset + 9]] + "-" + byteToHex[arr[offset + 10]] + byteToHex[arr[offset + 11]] + byteToHex[arr[offset + 12]] + byteToHex[arr[offset + 13]] + byteToHex[arr[offset + 14]] + byteToHex[arr[offset + 15]];
}

// node_modules/uuid/dist/esm-browser/native.js
var randomUUID = typeof crypto !== "undefined" && crypto.randomUUID && crypto.randomUUID.bind(crypto);
var native_default = {
  randomUUID
};

// node_modules/uuid/dist/esm-browser/v4.js
function v4(options, buf, offset) {
  if (native_default.randomUUID && !buf && !options) {
    return native_default.randomUUID();
  }
  options = options || {};
  const rnds = options.random || (options.rng || rng)();
  rnds[6] = rnds[6] & 15 | 64;
  rnds[8] = rnds[8] & 63 | 128;
  if (buf) {
    offset = offset || 0;
    for (let i = 0; i < 16; ++i) {
      buf[offset + i] = rnds[i];
    }
    return buf;
  }
  return unsafeStringify(rnds);
}
var v4_default = v4;

// node_modules/idb/build/index.js
var instanceOfAny = (object, constructors) => constructors.some((c) => object instanceof c);
var idbProxyableTypes;
var cursorAdvanceMethods;
function getIdbProxyableTypes() {
  return idbProxyableTypes || (idbProxyableTypes = [
    IDBDatabase,
    IDBObjectStore,
    IDBIndex,
    IDBCursor,
    IDBTransaction
  ]);
}
function getCursorAdvanceMethods() {
  return cursorAdvanceMethods || (cursorAdvanceMethods = [
    IDBCursor.prototype.advance,
    IDBCursor.prototype.continue,
    IDBCursor.prototype.continuePrimaryKey
  ]);
}
var transactionDoneMap = /* @__PURE__ */ new WeakMap();
var transformCache = /* @__PURE__ */ new WeakMap();
var reverseTransformCache = /* @__PURE__ */ new WeakMap();
function promisifyRequest(request) {
  const promise = new Promise((resolve, reject) => {
    const unlisten = () => {
      request.removeEventListener("success", success);
      request.removeEventListener("error", error);
    };
    const success = () => {
      resolve(wrap(request.result));
      unlisten();
    };
    const error = () => {
      reject(request.error);
      unlisten();
    };
    request.addEventListener("success", success);
    request.addEventListener("error", error);
  });
  reverseTransformCache.set(promise, request);
  return promise;
}
function cacheDonePromiseForTransaction(tx) {
  if (transactionDoneMap.has(tx))
    return;
  const done = new Promise((resolve, reject) => {
    const unlisten = () => {
      tx.removeEventListener("complete", complete);
      tx.removeEventListener("error", error);
      tx.removeEventListener("abort", error);
    };
    const complete = () => {
      resolve();
      unlisten();
    };
    const error = () => {
      reject(tx.error || new DOMException("AbortError", "AbortError"));
      unlisten();
    };
    tx.addEventListener("complete", complete);
    tx.addEventListener("error", error);
    tx.addEventListener("abort", error);
  });
  transactionDoneMap.set(tx, done);
}
var idbProxyTraps = {
  get(target, prop, receiver) {
    if (target instanceof IDBTransaction) {
      if (prop === "done")
        return transactionDoneMap.get(target);
      if (prop === "store") {
        return receiver.objectStoreNames[1] ? void 0 : receiver.objectStore(receiver.objectStoreNames[0]);
      }
    }
    return wrap(target[prop]);
  },
  set(target, prop, value) {
    target[prop] = value;
    return true;
  },
  has(target, prop) {
    if (target instanceof IDBTransaction && (prop === "done" || prop === "store")) {
      return true;
    }
    return prop in target;
  }
};
function replaceTraps(callback) {
  idbProxyTraps = callback(idbProxyTraps);
}
function wrapFunction(func) {
  if (getCursorAdvanceMethods().includes(func)) {
    return function(...args) {
      func.apply(unwrap(this), args);
      return wrap(this.request);
    };
  }
  return function(...args) {
    return wrap(func.apply(unwrap(this), args));
  };
}
function transformCachableValue(value) {
  if (typeof value === "function")
    return wrapFunction(value);
  if (value instanceof IDBTransaction)
    cacheDonePromiseForTransaction(value);
  if (instanceOfAny(value, getIdbProxyableTypes()))
    return new Proxy(value, idbProxyTraps);
  return value;
}
function wrap(value) {
  if (value instanceof IDBRequest)
    return promisifyRequest(value);
  if (transformCache.has(value))
    return transformCache.get(value);
  const newValue = transformCachableValue(value);
  if (newValue !== value) {
    transformCache.set(value, newValue);
    reverseTransformCache.set(newValue, value);
  }
  return newValue;
}
var unwrap = (value) => reverseTransformCache.get(value);
function openDB(name, version, { blocked, upgrade, blocking, terminated } = {}) {
  const request = indexedDB.open(name, version);
  const openPromise = wrap(request);
  if (upgrade) {
    request.addEventListener("upgradeneeded", (event) => {
      upgrade(wrap(request.result), event.oldVersion, event.newVersion, wrap(request.transaction), event);
    });
  }
  if (blocked) {
    request.addEventListener("blocked", (event) => blocked(
      // Casting due to https://github.com/microsoft/TypeScript-DOM-lib-generator/pull/1405
      event.oldVersion,
      event.newVersion,
      event
    ));
  }
  openPromise.then((db) => {
    if (terminated)
      db.addEventListener("close", () => terminated());
    if (blocking) {
      db.addEventListener("versionchange", (event) => blocking(event.oldVersion, event.newVersion, event));
    }
  }).catch(() => {
  });
  return openPromise;
}
var readMethods = ["get", "getKey", "getAll", "getAllKeys", "count"];
var writeMethods = ["put", "add", "delete", "clear"];
var cachedMethods = /* @__PURE__ */ new Map();
function getMethod(target, prop) {
  if (!(target instanceof IDBDatabase && !(prop in target) && typeof prop === "string")) {
    return;
  }
  if (cachedMethods.get(prop))
    return cachedMethods.get(prop);
  const targetFuncName = prop.replace(/FromIndex$/, "");
  const useIndex = prop !== targetFuncName;
  const isWrite = writeMethods.includes(targetFuncName);
  if (
    // Bail if the target doesn't exist on the target. Eg, getAll isn't in Edge.
    !(targetFuncName in (useIndex ? IDBIndex : IDBObjectStore).prototype) || !(isWrite || readMethods.includes(targetFuncName))
  ) {
    return;
  }
  const method = async function(storeName, ...args) {
    const tx = this.transaction(storeName, isWrite ? "readwrite" : "readonly");
    let target2 = tx.store;
    if (useIndex)
      target2 = target2.index(args.shift());
    return (await Promise.all([
      target2[targetFuncName](...args),
      isWrite && tx.done
    ]))[0];
  };
  cachedMethods.set(prop, method);
  return method;
}
replaceTraps((oldTraps) => ({
  ...oldTraps,
  get: (target, prop, receiver) => getMethod(target, prop) || oldTraps.get(target, prop, receiver),
  has: (target, prop) => !!getMethod(target, prop) || oldTraps.has(target, prop)
}));
var advanceMethodProps = ["continue", "continuePrimaryKey", "advance"];
var methodMap = {};
var advanceResults = /* @__PURE__ */ new WeakMap();
var ittrProxiedCursorToOriginalProxy = /* @__PURE__ */ new WeakMap();
var cursorIteratorTraps = {
  get(target, prop) {
    if (!advanceMethodProps.includes(prop))
      return target[prop];
    let cachedFunc = methodMap[prop];
    if (!cachedFunc) {
      cachedFunc = methodMap[prop] = function(...args) {
        advanceResults.set(this, ittrProxiedCursorToOriginalProxy.get(this)[prop](...args));
      };
    }
    return cachedFunc;
  }
};
async function* iterate(...args) {
  let cursor = this;
  if (!(cursor instanceof IDBCursor)) {
    cursor = await cursor.openCursor(...args);
  }
  if (!cursor)
    return;
  cursor = cursor;
  const proxiedCursor = new Proxy(cursor, cursorIteratorTraps);
  ittrProxiedCursorToOriginalProxy.set(proxiedCursor, cursor);
  reverseTransformCache.set(proxiedCursor, unwrap(cursor));
  while (cursor) {
    yield proxiedCursor;
    cursor = await (advanceResults.get(proxiedCursor) || cursor.continue());
    advanceResults.delete(proxiedCursor);
  }
}
function isIteratorProp(target, prop) {
  return prop === Symbol.asyncIterator && instanceOfAny(target, [IDBIndex, IDBObjectStore, IDBCursor]) || prop === "iterate" && instanceOfAny(target, [IDBIndex, IDBObjectStore]);
}
replaceTraps((oldTraps) => ({
  ...oldTraps,
  get(target, prop, receiver) {
    if (isIteratorProp(target, prop))
      return iterate;
    return oldTraps.get(target, prop, receiver);
  },
  has(target, prop) {
    return isIteratorProp(target, prop) || oldTraps.has(target, prop);
  }
}));

// src/lib/db.ts
var DB_NAME = "web-clipper-db";
var DB_VERSION = 5;
var CLIPS_STORE = "clips";
var SPACES_STORE = "spaces";
var META_STORE = "meta";
var DEFAULT_SPACE_ID = "default";
var dbPromise = null;
function getDB() {
  if (!dbPromise) {
    dbPromise = openDB(DB_NAME, DB_VERSION, {
      upgrade(db, oldVersion) {
        if (oldVersion < 1) {
          if (!db.objectStoreNames.contains(CLIPS_STORE)) {
            const store = db.createObjectStore(CLIPS_STORE, { keyPath: "id" });
            store.createIndex("by-type", "type");
            store.createIndex("by-timestamp", "timestamp");
            store.createIndex("by-space", "spaceId");
          }
          if (!db.objectStoreNames.contains(SPACES_STORE)) {
            const spaceStore = db.createObjectStore(SPACES_STORE, { keyPath: "id" });
            const defaultSpace = {
              id: DEFAULT_SPACE_ID,
              name: "My Space",
              createdAt: Date.now(),
              isDefault: true
            };
            spaceStore.add(defaultSpace);
          }
          if (!db.objectStoreNames.contains(META_STORE)) {
            db.createObjectStore(META_STORE);
          }
        }
        if (oldVersion < 5 && oldVersion >= 1) {
          if (!db.objectStoreNames.contains(SPACES_STORE)) {
            const spaceStore = db.createObjectStore(SPACES_STORE, { keyPath: "id" });
            const defaultSpace = {
              id: DEFAULT_SPACE_ID,
              name: "My Space",
              createdAt: Date.now(),
              isDefault: true
            };
            spaceStore.add(defaultSpace);
          }
        }
      },
      blocked() {
      }
    });
  }
  return dbPromise;
}
async function addClip(clip) {
  const db = await getDB();
  const clipWithSpace = { ...clip, spaceId: clip.spaceId || DEFAULT_SPACE_ID };
  await db.put(CLIPS_STORE, clipWithSpace);
  notifySidebar("clip-added", clipWithSpace);
}
async function deleteClip(id) {
  const db = await getDB();
  await db.delete(CLIPS_STORE, id);
  notifySidebar("clip-deleted", { id });
}
async function getAllClips(spaceId = DEFAULT_SPACE_ID) {
  const db = await getDB();
  try {
    const clips = await db.getAllFromIndex(CLIPS_STORE, "by-timestamp");
    return clips.filter((c) => c.spaceId === spaceId).reverse();
  } catch {
    const clips = await db.getAll(CLIPS_STORE);
    return clips.filter((c) => c.spaceId === spaceId).reverse();
  }
}
async function searchClips(query, spaceId = DEFAULT_SPACE_ID) {
  const allClips = await getAllClips(spaceId);
  const lowerQuery = query.toLowerCase();
  return allClips.filter(
    (clip) => clip.content.toLowerCase().includes(lowerQuery) || clip.title?.toLowerCase().includes(lowerQuery) || clip.url?.toLowerCase().includes(lowerQuery)
  );
}
async function clearAllClips(spaceId = DEFAULT_SPACE_ID) {
  const db = await getDB();
  const allClips = await db.getAll(CLIPS_STORE);
  const tx = db.transaction(CLIPS_STORE, "readwrite");
  for (const clip of allClips) {
    if (clip.spaceId === spaceId) {
      await tx.store.delete(clip.id);
    }
  }
  await tx.done;
  notifySidebar("clips-cleared", null);
}
async function markAllAsSeen() {
  const db = await getDB();
  const now = Date.now();
  await db.put(META_STORE, now, "lastSeenTimestamp");
  notifySidebar("marked-seen", null);
}
async function getBadgeState(spaceId = DEFAULT_SPACE_ID) {
  const db = await getDB();
  const clips = await db.getAll(CLIPS_STORE);
  const filteredClips = clips.filter((c) => c.spaceId === spaceId);
  const lastSeenTimestamp = await db.get(META_STORE, "lastSeenTimestamp") || 0;
  const hasUnread = filteredClips.some((clip) => clip.timestamp > lastSeenTimestamp);
  return {
    hasUnread,
    totalCount: filteredClips.length,
    lastSeenTimestamp
  };
}
async function notifySidebar(action, data) {
  try {
    await chrome.runtime.sendMessage({ action, data });
  } catch {
  }
}

// background/service-worker.ts
async function isSidebarOpen() {
  const result = await chrome.storage.local.get("sidebarOpen");
  return result.sidebarOpen === true;
}
async function setSidebarOpen(open) {
  await chrome.storage.local.set({ sidebarOpen: open });
}
async function setBadge() {
  try {
    const state = await getBadgeState();
    const sidebarIsOpen = await isSidebarOpen();
    if (state.totalCount > 0 && !sidebarIsOpen) {
      await chrome.action.setBadgeText({ text: "\xB7" });
      await chrome.action.setBadgeBackgroundColor({ color: "#6366F1" });
    } else {
      await chrome.action.setBadgeText({ text: "" });
    }
  } catch (e) {
  }
}
chrome.runtime.onInstalled.addListener(() => {
  createContextMenus();
  configureSidePanel();
  setBadge();
});
chrome.runtime.onStartup.addListener(async () => {
  await setSidebarOpen(false);
  setBadge();
});
async function configureSidePanel() {
  try {
    await chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
    chrome.runtime.onMessage.addListener((message) => {
      if (message.action === "sidebar-opened") {
        setSidebarOpen(true);
        markAllAsSeen();
        setBadge();
      } else if (message.action === "sidebar-closed") {
        setSidebarOpen(false);
        setBadge();
      }
      return false;
    });
  } catch (e) {
  }
}
chrome.action.onClicked.addListener(async (tab) => {
  if (tab.windowId) {
    await chrome.sidePanel.open({ windowId: tab.windowId });
    await setSidebarOpen(true);
    await markAllAsSeen();
    await setBadge();
  }
});
function createContextMenus() {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({
      id: "save-text",
      title: "Web Clipper - Save text",
      contexts: ["selection"]
    });
    chrome.contextMenus.create({
      id: "save-image",
      title: "Web Clipper - Save image",
      contexts: ["image"]
    });
    chrome.contextMenus.create({
      id: "save-link",
      title: "Web Clipper - Save link",
      contexts: ["link"]
    });
    chrome.contextMenus.create({
      id: "save-page",
      title: "Web Clipper - Save page",
      contexts: ["page"]
    });
  });
}
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (!tab?.id) return;
  const showToast = async (message) => {
    await chrome.tabs.sendMessage(tab.id, { action: "show-toast", message }).catch(() => {
    });
  };
  switch (info.menuItemId) {
    case "save-text":
      if (info.selectionText) {
        await captureText(info.selectionText, tab);
        await showToast("Text saved to Web Clipper");
      }
      break;
    case "save-image":
      if (info.srcUrl) {
        await captureImage(info.srcUrl, info.altText || "", tab);
        await showToast("Image saved to Web Clipper");
      }
      break;
    case "save-link":
      if (info.linkUrl) {
        await captureLink(info.linkUrl, info.linkText || info.linkUrl, tab);
        await showToast("Link saved to Web Clipper");
      }
      break;
    case "save-page":
      if (tab.url && tab.title) {
        await capturePage(tab.url, tab.title, tab);
        await showToast("Page saved to Web Clipper");
      }
      break;
  }
});
chrome.commands.onCommand.addListener(async (command, tab) => {
  if (command === "_execute_side_panel") {
    if (tab?.windowId) {
      await chrome.sidePanel.open({ windowId: tab.windowId });
      await setSidebarOpen(true);
      await markAllAsSeen();
      await setBadge();
    }
    return;
  }
  if (command === "capture") {
    try {
      if (tab?.id && tab.url) {
        const selection = await chrome.tabs.sendMessage(tab.id, { action: "get-selection" }).catch(() => null);
        if (selection) {
          const clip = await captureText(selection, tab);
          await chrome.tabs.sendMessage(tab.id, { action: "show-toast", message: "Text saved to Web Clipper" }).catch(() => {
          });
        } else {
          await capturePage(tab.url, tab.title || "Untitled", tab);
          await chrome.tabs.sendMessage(tab.id, { action: "show-toast", message: "Page saved to Web Clipper" }).catch(() => {
          });
        }
      }
    } catch (error) {
    }
  }
});
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  handleMessage(message).then(sendResponse).catch((e) => sendResponse({ error: e.message }));
  return true;
});
async function handleMessage(message) {
  switch (message.action) {
    case "add-clip":
      await addClip(message.data);
      await setBadge();
      return { success: true };
    case "delete-clip":
      await deleteClip(message.data);
      await setBadge();
      return { success: true };
    case "get-clips":
      return { clips: await getAllClips(message.data || DEFAULT_SPACE_ID) };
    case "search-clips":
      return { clips: await searchClips(message.data) };
    case "clear-all":
      await clearAllClips();
      await setBadge();
      return { success: true };
    case "mark-seen":
      await markAllAsSeen();
      await setBadge();
      return { success: true };
    case "sidebar-opened":
      await setSidebarOpen(true);
      await markAllAsSeen();
      await setBadge();
      return { success: true };
    case "sidebar-closed":
      await setSidebarOpen(false);
      await setBadge();
      return { success: true };
    case "capture-page":
      return await handleCapturePage(message.data);
    case "get-commands":
      try {
        const commands = await chrome.commands.getAll();
        const captureCommand = commands.find((c) => c.name === "capture");
        return { shortcut: captureCommand?.shortcut || null };
      } catch {
        return { shortcut: null };
      }
    default:
      return { error: "Unknown action" };
  }
}
async function handleCapturePage(data) {
  const tab = await getCurrentTab();
  if (!tab) return {};
  const clip = {
    id: v4_default(),
    type: data.type,
    content: data.content,
    url: data.url || tab.url,
    title: data.title || tab.title,
    favicon: data.pageFavicon || await getFavicon(tab.url || ""),
    timestamp: Date.now(),
    spaceId: DEFAULT_SPACE_ID
  };
  if (data.imageUrl) {
    clip.imageUrl = data.imageUrl;
    clip.imageAlt = data.imageAlt;
  }
  await addClip(clip);
  await setBadge();
  return { clip };
}
async function captureText(text, tab) {
  const clip = {
    id: v4_default(),
    type: "text",
    content: text,
    url: tab.url,
    title: tab.title,
    favicon: await getFavicon(tab.url || ""),
    timestamp: Date.now(),
    spaceId: DEFAULT_SPACE_ID
  };
  await addClip(clip);
  await setBadge();
  return clip;
}
async function captureImage(imageUrl, alt, tab) {
  const clip = {
    id: v4_default(),
    type: "image",
    content: imageUrl,
    url: tab.url,
    title: tab.title,
    favicon: await getFavicon(tab.url || ""),
    imageUrl,
    imageAlt: alt,
    timestamp: Date.now(),
    spaceId: DEFAULT_SPACE_ID
  };
  await addClip(clip);
  await setBadge();
  return clip;
}
async function captureLink(linkUrl, linkText, tab) {
  const clip = {
    id: v4_default(),
    type: "link",
    content: linkText,
    url: linkUrl,
    title: tab.title,
    favicon: await getFavicon(tab.url || ""),
    timestamp: Date.now(),
    spaceId: DEFAULT_SPACE_ID
  };
  await addClip(clip);
  await setBadge();
  return clip;
}
async function capturePage(url, title, tab) {
  const clip = {
    id: v4_default(),
    type: "link",
    content: title,
    url,
    title,
    favicon: await getFavicon(url),
    timestamp: Date.now(),
    spaceId: DEFAULT_SPACE_ID
  };
  await addClip(clip);
  await setBadge();
  return clip;
}
async function getCurrentTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}
async function getFavicon(url) {
  try {
    const urlObj = new URL(url);
    return `https://www.google.com/s2/favicons?domain=${urlObj.hostname}&sz=32`;
  } catch {
    return "";
  }
}
